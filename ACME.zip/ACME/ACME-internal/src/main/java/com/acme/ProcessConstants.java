package com.acme;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "ACME-internal"; // BPMN Process ID

}
